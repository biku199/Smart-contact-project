package com.techpro.employee.designation;
import java.util.List;

public interface DesignationDao {
    List<DesignationDTO> getAllList();
}
