package com.techpro.employee.employee;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class EmployeeDTO {

    private Integer id;

    private String name;

    private String birth;

    private String address;

    private String mobile;

    private String email;


}
