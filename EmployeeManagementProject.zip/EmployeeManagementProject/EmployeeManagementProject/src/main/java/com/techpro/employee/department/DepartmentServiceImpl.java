package com.techpro.employee.department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;

@Service
public class DepartmentServiceImpl {


    private DepartmentService departmentService ;

    @Autowired
    private DepartmentServiceImpl(DepartmentService departmentService )
    {

         this.departmentService=departmentService;

    }
    public List<DepartmentDTO> getAllBasicInfo() {
        return departmentService.getAllBasicListOfDepartment();
    }
    public List<Department> findAllDepartmentList() {
        return  departmentService.findAllListOfDepartment();
    }

    public boolean saveOrUpdate(DepartmentDTO departmentDTO){
        return departmentService.save(dtoToEntity(departmentDTO))!=null ;
    }

    public Department dtoToEntity(DepartmentDTO departmentDTO){
        Department department = null;
        //for update case
        Integer id = departmentDTO.getId();
        if(id != null)department = departmentService.findById(id);
        Date date = new Date();
        //to check update or save
        if(department == null){
            //save case
            department = new Department();
            department.setStatus(true);
            department.setCreatedDate(date);
        }
        department.setName(departmentDTO.getName());
        department.setUpdatedDate(date);

        return department;
    }

    //delete department
    public boolean delete(int id) {
        return departmentService.deleteById(id);
    }

}
