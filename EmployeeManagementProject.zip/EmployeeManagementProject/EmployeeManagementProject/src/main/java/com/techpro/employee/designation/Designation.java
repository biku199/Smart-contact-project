package com.techpro.employee.designation;
import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Entity
@Data
public class Designation {

    @Id@GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private String name;

    private Date createdDate;

    private Date updatedDate;

    private boolean status;

    @Column(columnDefinition = "boolean default false")
    private boolean deleteStatus;


}


