package com.techpro.employee.designation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;


@Service
public class DesignationServiceImpl {
    private final DesignationService designationService;
    @Autowired
     private DesignationServiceImpl(DesignationService designationService)
     {
         this.designationService=designationService;
     }
//     public List<DesignationDTO> findListOfDesignation()
//     {
//
//          return designationService.findAllListOfDesignation();
//     }
//
    public List<DesignationDTO> findAllDepartmentList() {
        return  designationService.findAllListOfDesignation();
    }
    // for save designation
     public boolean save(DesignationDTO designationDTO)
     {
         Designation designation=new Designation();
         designation.setName(designationDTO.getName());
         Date date =new Date();
         designation.setCreatedDate(new Date());
         designation.setUpdatedDate(new Date());
         designation.setStatus(true);
         designation.setDeleteStatus(false);
         try{
             System.out.println("Hello service");
             designationService.save(designation);
         }catch(Exception e){
             e.printStackTrace();
         }

         return true;
     }
     public boolean saveOrUpdate(DesignationDTO designationDTO)
     {
         Designation designation = null;
         //for update case
         Integer id = designationDTO.getId();
         if(id != null) {
             designation = designationService.findById(id);
         }
         Date date = new Date();
         //to check update or save
         if(designation == null){
             //save case
             designation = new Designation();
             designation.setStatus(true);
             designation.setCreatedDate(date);
             System.out.println("Done");
         }
         designation.setName(designationDTO.getName());
         designation.setUpdatedDate(date);

         return true;
     }
}
