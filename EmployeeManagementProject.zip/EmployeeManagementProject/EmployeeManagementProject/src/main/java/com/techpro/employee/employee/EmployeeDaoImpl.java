package com.techpro.employee.employee;

import com.techpro.employee.designation.DesignationDTO;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao{

    @PersistenceContext
    private EntityManager entityManager;
    @Override
    public List<EmployeeDTO> getAllList() {
        String queryString = "SELECT id,name FROM employee WHERE status=true AND delete_status=false";

        Session session = entityManager.unwrap(Session.class).getSession();
        Query query = session.createSQLQuery(queryString);
        query.unwrap(org.hibernate.query.Query.class).setResultTransformer(Transformers.aliasToBean(EmployeeDao.class));

        return query.getResultList();
    }



}
