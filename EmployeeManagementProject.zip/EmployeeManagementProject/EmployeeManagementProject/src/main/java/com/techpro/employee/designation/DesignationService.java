package com.techpro.employee.designation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DesignationService {
    private final DesignationRepository designationRepository;

     @Autowired
     private  DesignationService(DesignationRepository designationRepository)
     {
           this.designationRepository=designationRepository;
     }
     //for save employee designation
     public Designation save(Designation designation)
     {
         return designationRepository.save(designation);
     }
     public Designation findById(int id)
     {
        return designationRepository.findById(id).orElse(null);
     }
     public List<DesignationDTO> findAllListOfDesignation()
    {
        return designationRepository.getAllList();
    }

}
