package com.techpro.employee.employee;
import com.techpro.employee.designation.Designation;
import com.techpro.employee.designation.DesignationDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.List;

@Service
public class EmployeeServiceImpl {

    private EmployeeService employeeService;
    @Autowired
    private EmployeeServiceImpl(EmployeeService employeeService)
    {
        this.employeeService=employeeService;
    }
    public List<EmployeeDTO> findListOfEmployee()
    {

        return employeeService.findAllListOfEmployee();
    }
    //for save employee
    public boolean save(EmployeeDTO employeeDTO)
    {

        Employee employee=new Employee();
        employee.setName(employeeDTO.getName());
        employee.setBirth(employeeDTO.getBirth());
        employee.setBirth(employee.getAddress());
        employee.setEmail(employee.getEmail());
        Date date =new Date();
        employee.setCreatedDate(new Date());
        employee.setUpdatedDate(new Date());
        employeeService.save(employee);
        return true;


    }
    public boolean saveOrUpdate(EmployeeDTO employeeDTO)
    {
        Employee employee= null;
        //for update case
        Integer id = employee.getId();
        if(id != null) {
            employee = employeeService.findById(id);
        }
        Date date = new Date();
        //to check update or save
        if(employee == null){
            //save case
            employee = new Employee();
            employee.setStatus(true);
            employee.setCreatedDate(date);
            System.out.println("Done");
        }
     	return false;

        employee.setUpdatedDate(date);
    employee.setName(employeeDTO.getName());
        return true;
    }
    public boolean delete(int id){return employeeService.deleteById(id);
    }
}
