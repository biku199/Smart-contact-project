package com.techpro.employee.designation;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DesignationDTO {

     private Integer id;

     private String name;
}
