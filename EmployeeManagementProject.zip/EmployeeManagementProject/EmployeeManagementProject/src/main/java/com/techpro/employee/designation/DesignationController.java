package com.techpro.employee.designation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin( origins = "*")
public class DesignationController {


    private DesignationServiceImpl designationServiceImpl;

    @Autowired
    private DesignationController(DesignationServiceImpl designationServiceImpl)
    {
        this.designationServiceImpl=designationServiceImpl;
    }
    @GetMapping("/designation")
    public  List<DesignationDTO>  findAllDesignationList()
    {
        return  designationServiceImpl.findAllDepartmentList();
    }

    @PostMapping("/designation")
    public boolean save(@RequestBody DesignationDTO designationDTO)
    {
        System.out.println("Hello");
        try{
            return designationServiceImpl.save(designationDTO);
        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
    @PutMapping("/designation")
    public boolean update(@RequestBody DesignationDTO designationDTO) {
        try {
            return designationServiceImpl.saveOrUpdate(designationDTO);

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

