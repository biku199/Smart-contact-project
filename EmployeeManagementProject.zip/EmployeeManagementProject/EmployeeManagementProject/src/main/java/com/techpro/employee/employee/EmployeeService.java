package com.techpro.employee.employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EmployeeService {


     private  EmployeeRepository employeeRepository;

     @Autowired
     private  EmployeeService(EmployeeRepository employeeRepository)
     {
          this.employeeRepository=employeeRepository;

     }

    public Employee save(Employee employee)
    {
        return  employeeRepository.save(employee);

    }

    public Employee findById(int id)
    {

        return employeeRepository.findById(id).orElse(null);

    }

    public List<EmployeeDTO> findAllListOfEmployee()
    {
        return employeeRepository.getAllList();
    }
    public boolean deleteById(int id) {
        try {
            Employee employee = findById(id);
            employee.setDeletedStatus(true);
            employeeRepository.save(employee);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


}
