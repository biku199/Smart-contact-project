package com.techpro.employee.department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

   @Autowired
    private DepartmentService(DepartmentRepository departmentRepository) {
       this.departmentRepository=departmentRepository;
    }

    //for save department
    public Department save(Department department) {
        return departmentRepository.save(department) ;
    }

    //for get department  by id
    public Department findById(int id)
    {
        return departmentRepository.findById(id).orElse(null);
    }

    //get all basic list of department
    public List<DepartmentDTO> getAllBasicListOfDepartment(){

        return departmentRepository.getAllBasicList();
    }

    public List<Department> findAllListOfDepartment()
    {
        return departmentRepository.findAllByDeleteStatus(false);
    }

    //completely deleted from database
    public boolean deleteById(int id){
        try{
            Department department = findById(id);
            department.setDeleteStatus(true);
            departmentRepository.save(department);
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }

            return true;
    }
}
