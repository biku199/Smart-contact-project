package com.techpro.employee;



public class Designation {





}
