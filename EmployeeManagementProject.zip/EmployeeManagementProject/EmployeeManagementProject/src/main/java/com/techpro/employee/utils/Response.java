package com.techpro.employee.utils;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Response {

    private Object body;

    private String message;

    private int statusCode;
}
