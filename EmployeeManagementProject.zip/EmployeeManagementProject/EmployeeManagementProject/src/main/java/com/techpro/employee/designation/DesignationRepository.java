package com.techpro.employee.designation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface DesignationRepository extends JpaRepository<Designation,Integer> ,DesignationDao {
    List<Designation> findAllByDeleteStatus (boolean deletedStatus);

}
