package com.techpro.employee.employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@CrossOrigin("*")
public class EmployeeController {
    private EmployeeServiceImpl employeeServiceImpl;

    @Autowired
    private EmployeeController(EmployeeServiceImpl employeeServiceServiceImpl)
    {
        this.employeeServiceImpl=employeeServiceServiceImpl;
    }


    @PostMapping("/employee")
    public boolean save(@RequestBody EmployeeDTO employeeDTO)
    {
        return employeeServiceImpl.save(employeeDTO);
    }

    @DeleteMapping("/employee/{id}")
    public boolean deleteById(@PathVariable("id") int id){
        return employeeServiceImpl.delete(id);
    }


    @GetMapping("/employee")
    public List<EmployeeDTO> findAllDesignationList()
    {
        return  employeeServiceImpl.findListOfEmployee();
    }

    @PutMapping("/employee")
    public boolean update(@RequestBody EmployeeDTO employeeDTO) {
        try {
            return employeeServiceImpl.saveOrUpdate(employeeDTO);

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }
}
