package com.techpro.employee.department;

import java.util.List;

public interface DepartmentDao {

     List<DepartmentDTO> getAllBasicList() ;




}
