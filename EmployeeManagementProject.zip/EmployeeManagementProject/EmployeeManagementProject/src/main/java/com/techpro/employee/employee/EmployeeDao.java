package com.techpro.employee.employee;

import java.util.List;

public interface EmployeeDao {

     List<EmployeeDTO> getAllList();
}

