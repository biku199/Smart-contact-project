package com.techpro.employee.department;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DepartmentDTO {


    private Integer id;

    private String name;





}
