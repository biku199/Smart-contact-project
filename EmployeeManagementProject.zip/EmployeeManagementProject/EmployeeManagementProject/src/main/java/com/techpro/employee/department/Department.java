package com.techpro.employee.department;
import lombok.Data;
import javax.persistence.*;
import java.util.Date;
@Entity
@Data
public class Department {

    @Id@GeneratedValue (strategy =GenerationType.AUTO)
    private int id;

    private String name;

    @Column(columnDefinition = "boolean default true")
    private boolean status;                         

    @Column(nullable = false, updatable = false)
    private Date createdDate;

    @Column(nullable = false)
    private Date updatedDate;

    @Column(columnDefinition = "boolean default false")
    private boolean deleteStatus;
}
