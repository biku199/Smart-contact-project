package com.techpro.employee.utils;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class Helper {

    public ResponseEntity<Response> getResponseEntity(Object body, String message, int statusCode){
        //return new ResponseEntity<>(Re)
        return null;
    }
}
