package com.techpro.employee.employee;
import com.techpro.employee.department.Department;
import com.techpro.employee.designation.Designation;
import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Entity
@Data
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private String name;

    private String birth;

    private String address;

    private String mobile;

    private String email;

    private Date createdDate;

    private Date updatedDate;

    private boolean status;

    @Column(columnDefinition = "boolean default false")
    private boolean deletedStatus;

    @OneToOne
    private Department department;

    @OneToOne
    private Designation designation;

}