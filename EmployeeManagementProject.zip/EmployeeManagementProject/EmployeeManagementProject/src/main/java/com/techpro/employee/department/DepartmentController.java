package com.techpro.employee.department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@CrossOrigin(origins = "*")
public class DepartmentController {

    private final DepartmentServiceImpl departmentServiceImpl;

    @Autowired
    private DepartmentController(DepartmentServiceImpl departmentServiceImpl) {
        this.departmentServiceImpl = departmentServiceImpl;
    }

    @GetMapping("/department")
    public List<Department> findAllDepartmentList() {
        return departmentServiceImpl.findAllDepartmentList();
    }


    @GetMapping("/department/findAllBasicInfo")
    public List<DepartmentDTO> findAllVBasicListOfDepartment(){
        return departmentServiceImpl.getAllBasicInfo();
    }
    /*
        save Department
        @Param DepartmentDTO
     */
    @PostMapping("/department")
    public boolean save(@RequestBody DepartmentDTO departmentDTO) {
        try {
            return departmentServiceImpl.saveOrUpdate(departmentDTO);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }}

    @PutMapping("/department")
    public boolean update(@RequestBody DepartmentDTO departmentDTO) {
        try {
            return departmentServiceImpl.saveOrUpdate(departmentDTO);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    @DeleteMapping("/department/{id}")
    public boolean deleteById(@PathVariable("id") int id){
        return departmentServiceImpl.delete(id);
    }

}
